# AI Auto Shorts (GitHub Actions Ready)

This is a clean, standalone Android app project configured to compile into a working `.apk` file directly on GitHub Actions (or locally using Gradle / Android Studio).

## How to build on GitHub:
1. Extract all files in this ZIP into your GitHub repository root.
2. Push to your `main` branch.
3. Go to the **Actions** tab on GitHub and watch **Android APK Build** run.
4. When complete, download `app-debug.apk` from the run's **Artifacts** section!
