package com.example.autoshorts;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.media.MediaMuxer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_VIDEO = 1001;
    private Uri selectedUri;
    private TextView status;
    private Button makeButton;
    private ProgressBar progress;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(28), dp(22), dp(20));
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setBackgroundColor(0xFFF7F4FF);

        TextView title = new TextView(this);
        title.setText("AI Auto Shorts");
        title.setTextSize(26);
        title.setTextColor(0xFF241A35);
        title.setGravity(Gravity.CENTER);
        root.addView(title, matchWrap());

        TextView intro = new TextView(this);
        intro.setText("Select a video from your gallery to generate a 30-second short clip. No cloud upload required.");
        intro.setTextSize(15);
        intro.setTextColor(0xFF494454);
        intro.setPadding(0, dp(16), 0, dp(20));
        root.addView(intro, matchWrap());

        Button pick = new Button(this);
        pick.setText("1. Choose Video");
        root.addView(pick, matchWrap());
        pick.setOnClickListener(v -> chooseVideo());

        makeButton = new Button(this);
        makeButton.setText("2. Generate 30s Short");
        makeButton.setEnabled(false);
        LinearLayout.LayoutParams bp = matchWrap();
        bp.topMargin = dp(12);
        root.addView(makeButton, bp);
        makeButton.setOnClickListener(v -> trimVideo());

        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(dp(44), dp(44));
        pp.topMargin = dp(20);
        root.addView(progress, pp);

        status = new TextView(this);
        status.setText("Status: Ready to select video");
        status.setTextSize(14);
        status.setTextColor(0xFF494454);
        status.setPadding(0, dp(18), 0, 0);
        root.addView(status, matchWrap());

        setContentView(root);
    }

    private void chooseVideo() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("video/*");
        startActivityForResult(i, PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_VIDEO && resultCode == RESULT_OK && data != null) {
            selectedUri = data.getData();
            if (selectedUri != null) {
                try {
                    getContentResolver().takePersistableUriPermission(selectedUri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                status.setText("Selected: " + displayName(selectedUri));
                makeButton.setEnabled(true);
            }
        }
    }

    private void trimVideo() {
        if (selectedUri == null) return;
        makeButton.setEnabled(false);
        progress.setVisibility(View.VISIBLE);
        status.setText("Processing video...");

        new Thread(() -> {
            String resultMsg;
            try {
                File outDir = new File(getExternalFilesDir(android.os.Environment.DIRECTORY_MOVIES), "AI_Auto_Shorts");
                if (!outDir.exists() && !outDir.mkdirs()) {
                    throw new Exception("Unable to create output directory");
                }
                String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
                File outFile = new File(outDir, "short_" + timeStamp + ".mp4");
                copyAndTrim(selectedUri, outFile);
                resultMsg = "Short created successfully!
Saved to: " + outFile.getAbsolutePath();
            } catch (Exception e) {
                resultMsg = "Error: " + e.getMessage();
            }

            final String finalMsg = resultMsg;
            new Handler(Looper.getMainLooper()).post(() -> {
                progress.setVisibility(View.GONE);
                status.setText(finalMsg);
                makeButton.setEnabled(true);
                Toast.makeText(this, finalMsg.contains("Error") ? "Processing Failed" : "Clip Created!", Toast.LENGTH_LONG).show();
            });
        }).start();
    }

    private void copyAndTrim(Uri uri, File output) throws Exception {
        MediaExtractor extractor = new MediaExtractor();
        extractor.setDataSource(this, uri, null);
        MediaMuxer muxer = new MediaMuxer(output.getAbsolutePath(), MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4);
        
        int trackCount = extractor.getTrackCount();
        int[] indexMap = new int[trackCount];
        boolean trackAdded = false;
        long durationUs = 30_000_000L; // 30 seconds limit

        for (int i = 0; i < trackCount; i++) {
            MediaFormat format = extractor.getTrackFormat(i);
            String mime = format.getString(MediaFormat.KEY_MIME);
            if (mime != null && (mime.startsWith("video/") || mime.startsWith("audio/"))) {
                indexMap[i] = muxer.addTrack(format);
                trackAdded = true;
            } else {
                indexMap[i] = -1;
            }
        }

        if (!trackAdded) throw new Exception("No audio/video track found");

        muxer.start();
        ByteBuffer buffer = ByteBuffer.allocate(2 * 1024 * 1024);
        android.media.MediaCodec.BufferInfo info = new android.media.MediaCodec.BufferInfo();

        for (int i = 0; i < trackCount; i++) {
            if (indexMap[i] >= 0) extractor.selectTrack(i);
        }

        extractor.seekTo(0, MediaExtractor.SEEK_TO_CLOSEST_SYNC);

        while (true) {
            int trackIndex = extractor.getSampleTrackIndex();
            if (trackIndex < 0) break;
            long sampleTime = extractor.getSampleTime();
            if (sampleTime < 0 || sampleTime > durationUs) break;

            if (indexMap[trackIndex] >= 0) {
                buffer.clear();
                int sampleSize = extractor.readSampleData(buffer, 0);
                if (sampleSize < 0) break;

                info.offset = 0;
                info.size = sampleSize;
                info.presentationTimeUs = sampleTime;
                info.flags = (extractor.getSampleFlags() & MediaExtractor.SAMPLE_FLAG_SYNC) != 0 ?
                        android.media.MediaCodec.BUFFER_FLAG_KEY_FRAME : 0;

                muxer.writeSampleData(indexMap[trackIndex], buffer, info);
            }
            if (!extractor.advance()) break;
        }

        try {
            muxer.stop();
        } finally {
            muxer.release();
            extractor.release();
        }
    }

    private String displayName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int index = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) return c.getString(index);
            }
        } catch (Exception ignored) {}
        return "Video";
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
    }
}
